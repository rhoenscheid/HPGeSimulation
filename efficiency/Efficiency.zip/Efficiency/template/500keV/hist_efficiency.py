import hist_class as hs
import pandas as pd
import numpy as np


def main():

    energies_probed = pd.read_csv("Peaks.csv")

    energies = pd.read_csv("energies.csv")
    

    total_events = 1e6

    hist = hs.my_hist(4096, energies, energies_probed, total_events)

    hist.efficiency_df(filename = "effi_df.csv", res = False)

if __name__ == "__main__":

    main()
