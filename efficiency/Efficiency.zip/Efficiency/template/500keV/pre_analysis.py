#Python Analysis Script"
import numpy as np
import uproot
import pandas as pd
import matplotlib.pyplot as plt


def get_df(filename):
    """
    Extract the pandas dataframe from the Root TTree.
    Input:
    -filename: Name of .root file
    Returns:
    -dataframe: Pandas dataframe with "event" and "Edep" column from .root file
    """
    print("Creating dataframe from file...")


    file = uproot.open(filename)
    tree = file["g4sntuple"]

    event_arr_0 = tree["event"].arrays(library='np')
    Edep_arr_0 = tree["Edep"].arrays(library='np')

    event_arr = np.array(event_arr_0['event'][:])
    Edep_arr = np.array(Edep_arr_0['Edep'][:][:])
    Edep_arr = [np.sum(Edep_arr[i]) for i in range(len(Edep_arr))]
    
    dataframe = pd.DataFrame(pd.DataFrame({'event' : event_arr, 'Edep' : Edep_arr}))

    dataframe.astype({'event': 'int64'})
    dataframe.astype({'Edep': 'float'})


    print("DataFrame created.")

    return dataframe

def hist_analysis(filename, resolution = None, peaks=[1.173, 1.332, 2.505]):
    """
    Obtain an array of the measured deposited energies.
    """

    dataframe = get_df(filename)

    energies = np.array(dataframe["Edep"])
    
    print("Computed deposited energies.")

    energies = pd.Series(energies)


    return energies

def pre_analysis(filename, resolution=None, peaks=[1.173, 1.332, 2.505]):
    """
    Main method to read the .root file and output a .csv for later analysis
    """
    
    energies = hist_analysis(filename, resolution)

    energies = energies[energies != 0.0]

    energies.to_csv("energies.csv", index=False, header=False)

    print("CSV-file saved. Ready for further analysis.")
    print(r"    Non-zero events =", len(energies))


if __name__ == "__main__":

    pre_analysis("sim_out.root")

    print("Success.")
