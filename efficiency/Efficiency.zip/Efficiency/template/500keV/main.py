import pre_analysis as pre
import add_resolution as res
import create_hist as his


def specify_filename():

    filename = "energies_res.csv"
	
    spec_file = input("The default filename is energies_res.csv. Would you like to change this? (Y/N): ")

    if spec_file == "Y":

        filename = input("Please specify filename: ")

        print("Filename registered as:", filename)

    print("Success.")


def main():
    
    #pre-analysis
    pre.pre_analysis("sim_out.root")


    #add resolution
    res.add_FWHM_resolution("energies.csv")
    

    #create interspec spectrum & plot histogram
    his.interspec_exp("energies_res.csv")
    his.plot_histogram("energies_res.csv")

if __name__ == "__main__":

    main()
