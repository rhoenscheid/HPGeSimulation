echo Running 20keV, 30keV and 2400keV simulation.

cd ../20keV
echo Running 20keV simulation
g4simple sim_point_source.mac
echo Analysing 20keV simulation
python main.py

cd ../30keV
echo Running 30keV simulation
g4simple sim_point_source.mac
echo Analysing 30keV simulation
python main.py

cd ../2400keV
echo Running 2400keV simulation
g4simple sim_point_source.mac
echo Analysing 2400keV simulation
python main.py

cd ../run-files
echo Done.

