echo Running 1600keV, 1800keV simulations.

cd ../1600keV
echo Running 1600keV simulation
g4simple sim_point_source.mac
echo Analysing 1600keV simulation
python main.py

cd ../1800keV
echo Running 1800keV simulation
g4simple sim_point_source.mac
echo Analysing 1800keV simulation
python main.py

cd ../run-files
echo Done.

