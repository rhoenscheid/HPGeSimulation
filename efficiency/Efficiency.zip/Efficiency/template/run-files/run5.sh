echo Running 800keV, 1000keV simulations.

cd ../800keV
echo Running 800keV simulation
g4simple sim_point_source.mac
echo Analysing 800keV simulation
python main.py

cd ../1000keV
echo Running 1000keV simulation
g4simple sim_point_source.mac
echo Analysing 1000keV simulation
python main.py

cd ../run-files
echo Done.

