echo Running 300keV, 500keV simulations.

cd ../300keV
echo Running 300keV simulation
g4simple sim_point_source.mac
echo Analysing 300keV simulation
python main.py

cd ../500keV
echo Running 500keV simulation
g4simple sim_point_source.mac
echo Analysing 500keV simulation
python main.py

cd ../run-files
echo Done.

