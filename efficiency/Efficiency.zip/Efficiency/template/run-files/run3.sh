echo Running 100keV, 200keV and 2000keV simulation.

cd ../100keV
echo Running 100keV simulation
g4simple sim_point_source.mac
echo Analysing 100keV simulation
python main.py

cd ../200keV
echo Running 200keV simulation
g4simple sim_point_source.mac
echo Analysing 200keV simulation
python main.py

cd ../2000keV
echo Running 2000keV simulation
g4simple sim_point_source.mac
echo Analysing 2000keV simulation
python main.py

cd ../run-files
echo Done.

