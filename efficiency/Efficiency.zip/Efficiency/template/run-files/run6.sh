echo Running 1200keV, 1400keV simulations.

cd ../1200keV
echo Running 1200keV simulation
g4simple sim_point_source.mac
echo Analysing 1200keV simulation
python main.py

cd ../1400keV
echo Running 1400keV simulation
g4simple sim_point_source.mac
echo Analysing 1400keV simulation
python main.py

cd ../run-files
echo Done.

