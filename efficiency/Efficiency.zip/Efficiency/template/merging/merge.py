import numpy as np
import pandas as pd
import os

def main():
    
    #files = ["energies_res1.csv", "energies_res2.csv","energies_res3.csv", "energies_res4.csv", "energies_res5.csv", "energies_res6.csv", "energies_res7.csv", "energies_res8.csv"]

    files = ["energies1.csv", "energies2.csv", "energies3.csv", "energies4.csv", "energies5.csv", "energies6.csv", "energies7.csv", "energies8.csv", "energies9.csv", "energies10.csv", "energies11.csv",  "energies12.csv", "energies13.csv", "energies14.csv", "energies15.csv", "energies16.csv", "energies17.csv"]
    sets = []

    for filename in files:

        if os.path.getsize(filename) != 0:
            
            sets.append(pd.read_csv(filename, header = None))
        
    #sets = [pd.read_csv(filename, header = None) for filename in files]
    
    merged = pd.concat(sets)

    merged.to_csv("energies.csv", header = False, index = False)

if __name__ == "__main__":

    main()
