import hist_class as hs
import pandas as pd
import numpy as np
import create_hist as ch

def main():

    energies_probed = pd.read_csv("Peaks.csv")

    energies = pd.read_csv("energies.csv")
    

    total_events = NEVENTS

    hist = hs.my_hist(4096, energies, energies_probed, total_events)

    eff_df = hist.efficiency_df(filename = "effi_df.csv", res = False)

    #plot the efficiency
    degrees = [2,3,4]
    [hs.plot_fit(eff_df, N = j) for j in degrees]

    ch.interspec_exp("energies.csv")
    


if __name__ == "__main__":

    main()
