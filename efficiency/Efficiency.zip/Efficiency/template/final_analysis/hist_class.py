import numpy as np
import pandas as pd
import add_resolution as res
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def find_between(array, low, high):
    """
    Primitively counts the number of values betweeen a lower and an upper bound.
    """
    between = [] #emtpy array to store the values in between low and high
    array = np.array(array)

    #convert to MeV
    low = low / 1000
    high = high / 1000

    for elem in array:
        
        if elem > low and elem < high:

            between.append(elem)

    counts = len(between) #obtain number of values in between low and high
    
    return counts

class my_hist:
    """
    Histogram with given number of bins, and energies.
    Please provide:
        -bins: Number of bins in the histogram
        -energies: energy values to be considered by the histogram.
        -peak_df: DataFrame with peak energies in keV and their associated branching ratios
        -total_counts: Number of total decays which occured in the simulation
    """
    
    def __init__(self, bins, energies, peak_df, total_counts):

        self.counts, self.limits = np.histogram(energies, bins = bins)

        self.energies = energies
        self.bins = bins
        self.peak_df = peak_df
        self.total_counts = total_counts

    def counts_range(self, low, high):
        """
        Returns the counts registered in this histogram between two values
        Inputs:
            -low: lower bound for the counting in MeV
            -high: upper boudn for the counting in MeV
        Output:
            -count: number of counts within the range.
            -bins_considered: number of bins within the range
        """
        #any limit greater than low and smaller than high is considered.
        count = 0
        bins_considered = 0
        unc = [] #store the uncertainties on individual bins here
        for j in range(self.bins):

            if self.limits[j] > low and self.limits[j] < high:

                count += self.counts[j]
                unc.append(np.sqrt(self.counts[j]))
                bins_considered += 1

        unc = np.array(unc)


        uncertainty = np.sqrt(np.sum(unc**2))

        return count, bins_considered, uncertainty
        
    def get_peak_count(self, peak, res = True):
        """
        Obtain the number of registered events at a given peak energy.
        Returns the number of registered counts in a region of 2 standard deviations around the peak.
        Inputs:
            -peak (float): energy of the peak in keV
        Outputs:
            -counts (int): number of counts in a region of two sigma around the peak
        """
        #ocnvert to MeV
        peak = peak / 1000

        if res:

            FWHM_peak = res.get_res(peak) #this is the standard deviation at the peak energy
 
            #convert back to keV
            upper_bound = peak + (4 * FWHM_peak)
            lower_bound = peak - (4 * FWHM_peak)

        if res == False:

            upper_bound = peak + 0.003
            lower_bound = peak - 0.003

        peak_count, bins_considered, uncertainty = self.counts_range(lower_bound, upper_bound)

        background_per_bin = self.get_peak_background(peak*1000)#estimate the background

        if (bins_considered * background_per_bin) > peak_count: #avoid negative peak counts
            
            print("Warning. Peak: ", peak," -- No counts above background. Counting 0.")

            return 0.001, 0.0001


        peak_count = peak_count - (bins_considered * background_per_bin)

        if peak_count == 0: #avoid divisions by 0 lateer or log(0) terms

            return 0.001, 0.0001

        return peak_count, uncertainty

    def get_peak_background(self, peak, res = True):
        """
        Returns an average background level around a peak.
        Input:
            -peak: energy of the peak in keV
        Output:
            -back_per_bin = background per bin around the peak
        """
        #Covnert peak energy to MeV
        peak = peak / 1000

        #look for the backgorund ca. 10 keV away from the peak in each direction
        back_low0 = peak - 0.004
        back_low1 = peak - 0.009

        back_high0 = peak + 0.004
        back_high1 = peak + 0.009

        high_counts0, bins_high, uncertainty_high = self.counts_range(back_high0, back_high1)
        low_counts0, bins_low, uncertainty_low = self.counts_range(back_low1, back_low0)

        if (bins_high + bins_low) == 0: #avoid division by 0
            return 0

        total_back = high_counts0 + low_counts0
        back_per_bin = total_back / (bins_high + bins_low)

        return back_per_bin
    
    def get_efficiency_at_peak(self, peak, BR, total_counts, res = True):
        """
        Obtain the recorded efficiency at a peak.
        Inputs:
            -peak: Energy value at the peak in keV
            -BR: branching ratio of photon emission at this energy
            -total_counts: number of simulated decays in the dataset
        Output:
            -efficiency: detection efficiency of detector at the given peak.
        """

        expected_counts = total_counts * BR

        measured_counts, uncertainty = self.get_peak_count(peak, res)

        print("We expect",expected_counts,"at peak",peak,". We measured",measured_counts,".")

        efficiency = measured_counts / expected_counts

        return efficiency

    def efficiency_points(self, res = True):
        """
        Obtain efficiency values at the peak energies.
        Inputs:
            -self.peak_df: DataFrame with peak energies in first column and their associated branching ratios in the second column.
            -self.total_counts: number of simulated decays in the dataset.
        """
        efficiency = []

        for j in range(len(self.peak_df["Energy"])):

            new_efficiency = self.get_efficiency_at_peak(self.peak_df["Energy"][j], self.peak_df["BR"][j], self.total_counts, res)
            efficiency.append(new_efficiency)

        return efficiency

    def efficiency_df(self, filename = None, res = True):
        """
        Returns a DataFrame with efficiency values at the peak energies. Useful for further formatting, espeecially when inspecting multiple isotopes.
        Inputs:
            -self.peak_df: DataFrame with peak energies in first column and their associated branching ratios in the second column.
            -self.total_counts: number of simulated decays in the dataset.
            -filename: If provided, the data will be saved in .csv format into the given file.
        Outputs:
            -new_df: DataFrame with absolute efficiency at peak energies.
        """
        #obtain efficiency data for given parameters
        efficiency = self.efficiency_points(res)

        new_df = pd.DataFrame({"Energy" : self.peak_df["Energy"], "Detection Efficiency" : efficiency})

        if filename:
            new_df.to_csv(filename, index = False, header = True)

        return new_df

    def plot_efficiency(self, res = True):
        """
        Plot full-peak efficiency against energy curve for the given histogram.
        Inputs:
            -self.peak_df: DataFrame with peak energies and their branching ratios
            -self.total_counts: Total number of simulated events.
        """
        df = efficiency_df(res)
        plt.figure()
        plt.plot(df["Energy"], df["Detection Efficiency"])
        plt.xlabel("Energy (keV)")
        plt.ylabel("Detection Efficiency")
        plt.title("Efficiency Calibration")
        plt.savefig("calibration.png", dpi = 300)


def efficiency_equation2(E, a, b, c):
    """
    2-nd degree ln(epsilon) = a + b * ln(E) + c * ln(E)^2 + ... fit
    The returned value is the logarithm of the efficiency.
    """
    global E0
    
    E0 = 1000
    eff_ln = a + b * np.log(E/E0) + c * (np.log(E/E0)**2)

    return eff_ln

def efficiency_equation3(E, a, b, c, d):
    """
    3-rd degree ln(epsilon) = a + b * ln(E) + c * ln(E)^2 + ... fit
    The returned value is the logarithm of the efficiency.
    """
    global E0

    E0 = 1000
    eff_ln = a + b * np.log(E/E0) + c * (np.log(E/E0)**2) + d * (np.log(E/E0)**3)

    return eff_ln

def efficiency_equation4(E, a, b, c, d, e):
    """
    4-th degree ln(epsilon) = a + b * ln(E) + c * ln(E)^2 + ... fit
    The returned value is the logarithm of the efficiency.
    """
    global E0

    E0 = 1000
    eff_ln = a + b * np.log(E/E0) + c * (np.log(E/E0)**2) + d * (np.log(E/E0)**3) + e * (np.log(E/E0) **4)

    return eff_ln

def perform_fit(df, N = 3):
    """
    Uses scipy.optimize.curve_fit to fit an energy efficiency curve of degree 4 to the given data.
    Fits the data using the ln(epsilon) method defined in efficiency_equatin2()
    Input:
        -df: DataFrame with Energy column and Detection Efficiency column
        -N: order of fit. Options: 2,3,4. Default: 3
    Output:
        -fit: fitting parameters
        -dfit: uncertainty in fitting parameters
    """

    x_data = np.array(df["Energy"])
    y_data = np.array(df["Detection Efficiency"])
    
    y_data = np.log(y_data)

    if N == 2:
        fit, cov = curve_fit(efficiency_equation2, x_data, y_data)
    if N == 3:
        fit, cov = curve_fit(efficiency_equation3, x_data, y_data)
    if N == 4:
        fit, cov = curve_fit(efficiency_equation4, x_data, y_data)

    dfit = [np.sqrt(cov[i,i]) for i in range(len(fit))]

    print("Fitting parameters: ", fit)
    print("Uncertainties: ", dfit)

    return fit, dfit

def plot_fit(df, N = 3):
    """
    Uses perform_fit() to obtain a least-squares regression to the efficiency_equation() function.
    Then plots the original data, including the result of the fit.
    Input:
        -df: DataFrame with Energy column and Detection Efficiency column
        -N: order of fit. Options: 2,3,4. Default: 3
    """
    fit, dfit = perform_fit(df, N)     
    
    length = 2500 #end the plot at 350% of the first energy value
    x_values = np.linspace(0.1, length, 600) #the plot at 80% of the first energy value
    
    if N == 2:
        y_values = efficiency_equation2(x_values, fit[0], fit[1], fit[2])
    if N == 3:
        y_values = efficiency_equation3(x_values, fit[0], fit[1], fit[2], fit[3])
    if N == 4:
        y_values = efficiency_equation4(x_values, fit[0], fit[1], fit[2], fit[3], fit[4])
    

    y_values = np.exp(y_values)
    
    plt.figure()
    #plot the fitted curve
    plt.plot(x_values, y_values, label = "Regression Curve")

    #plot the datapoint
    plt.plot(df["Energy"], df["Detection Efficiency"], '.', label = "Data")
    
    plt.xlabel("Energy [keV]")
    plt.ylabel("Full Photopeak Efficiency")
    plt.legend(loc = "best")
    
    #add the fitting parameters onto the plot
    text_str = []
    [text_str.append(str(f"$a_{i}$ = " + str(np.round(fit[i], 2)) + f"$\pm$" + str(np.round(dfit[i], 2)))) for i in range(len(fit))]
    #print(text_str)
    xmin, xmax, ymin, ymax = plt.axis()

    for i in range(len(fit)):
        plt.text(x = 1900, y = ((0.76 - 0.05 * i) * ymax) , s = text_str[i])

    if N == 2:
        plt.savefig("Fitted_Curve_deg2.png", dpi = 300)
        np.savetxt("parameters_deg2.csv", fit, delimiter = ",")
        np.savetxt("unc_deg2.csv", dfit, delimiter = ",")
    if N == 3:
        plt.savefig("Fitted_Curve_deg3.png", dpi = 300)
        np.savetxt("parameters_deg3.csv", fit, delimiter = ",")
        np.savetxt("unc_deg3.csv", dfit, delimiter = ",")
    if N == 4:
        plt.savefig("Fitted_Curve_deg4.png", dpi = 300)
        np.savetxt("parameters_deg4.csv", fit, delimiter = ",")
        np.savetxt("unc_deg4.csv", dfit, delimiter = ",")

def get_scaling_factor(time, Nevents):
    """
    When comparing a simulated and a measured spectrum, we need to scale the measured spectrum to represent the same total number of decays.
    This function computes the factor by which the simulated counts have to be multiplied to be compared to the measured spectrum.
    Assumes the activity of source 43 (Co-60) as 5.476 kBq.
    Inputs:
        -time: Real time of measured spectrum in [s].
        -Nevents: Number of events in the simulation.
    Output:
        -factor: Scaling factor to be applied to simulated counts.
    """
    
    activity =  5476 #in [Bq]

    N_total = activity * time #Total decays in measured dataset

    factor = N_total / Nevents #scaling factor

    return factor



def plot_efficiency(df):
    """
    Plot the efficiency against energy curve for the given dataframe of Energy and Efficiency values.
    Input:
        -df: DataFrame with peak energies and their measured efficiencies.
    """
    plt.plot(df["Energy"], df["Detection Efficiency"])
    plt.xlabel("Energy (keV)")
    plt.ylabel("Detection Efficiency")
    plt.title("Efficiency Calibration")
    plt.savefig("calibration.png", dpi = 300)

def read_peaks(filename):
    """
    Reads the .csv file storing the peak data
    """
    df = pd.read_csv(filename) 
    df["Energy"].astype("float")
    df["BR"].astype("float")

    return df

def read_energies(filename):
    """
    Reads the .csv file storing the deposited energy values.
    """

    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]

    return energies

def counts_and_ratios(hist_obj, peak_df):
    """
    Evaluates the number of counts in the Co-60 peak-energies and the summation peak, with uncertainties.
    Computes the ratio of the number of counts in the 2505 keV peak to the two main photopeaks.
    Saves results to Peak_counts.csv, summarising the oounts and ratios with their uncertainties.
    Inputs:
        -hist_obj: Histogram object of the my_hist class, containing the energy histogram.
        -peak_df: DataFrame with the peak energies of Co-60
    """

    p_counts = []
    p_unc = []

    for peak in peak_df["Energy"]:

        new_counts, new_unc = hist_obj.get_peak_count(peak)

        p_counts.append(new_counts)
        p_unc.append(new_unc)

    _2505_to_1173 = p_counts[2] / p_counts[0]
    _2505_to_1173_unc = np.sqrt( (p_unc[2]/p_counts[0])**2 + (p_counts[2] * p_unc[0] / (p_counts[0]**2))**2 )

    _2505_to_1332 = p_counts[2] / p_counts[1]
    _2505_to_1332_unc = np.sqrt( (p_unc[2]/p_counts[1])**2 + (p_counts[2] * p_unc[1] / (p_counts[1]**2))**2 )

    result = pd.DataFrame({'1173 keV' : p_counts[0],
        '1173 keV (unc)' : p_unc[0],
        '1332 keV' : p_counts[1],
        '1332 keV (unc)' : p_unc[1],
        '2505 keV' : p_counts[2],
        '2505 keV (unc)' : p_unc[2],
        '2505 to 1173' : _2505_to_1173,
        '2505 to 1173 (unc)' : _2505_to_1173_unc,
        '2505 to 1332' : _2505_to_1332,
        '2505 to 1332 (unc)' : _2505_to_1332_unc,
        }, index = [0])
    print(result)
    result.to_csv('Peak_counts.csv', header = True, index = False)
    return result

def main():

    #read Bi-207, Bi-214 and Co-60 energies
    #energies_Bi207 = read_energies("energies_res_Bi207.csv")
    energies_Co60 = read_energies("energies_res.csv")
    #energies_Bi214 = read_energies("energies_res_Bi214.csv")
    
    #read Bi-207 peaks
    #peak_df_Bi207 = read_peaks("peaksBi207.csv")
    #read Co-60 peaks
    peak_df_Co60 = read_peaks("peaksCo60.csv")
    #read Bi-214 peaks
    #peak_df_Bi214 = read_peaks("peaksBi214.csv")

    total_counts = 120e6

    #hist_Bi207 = my_hist(4096, energies_Bi207, peak_df_Bi207, total_counts)
    hist_Co60 = my_hist(4096, energies_Co60, peak_df_Co60, total_counts)
    #hist_Bi214 = my_hist(4096, energies_Bi214, peak_df_Bi214, total_counts)

    Co60_eff = hist_Co60.efficiency_df()
    #Bi207_eff = hist_Bi207.efficiency_df()
    #Bi214_eff = hist_Bi214.efficiency_df()

    #OBTAIN COUNTS AT PEAKS
    result = counts_and_ratios(hist_Co60, peak_df_Co60)

if __name__ == "__main__":
    
    main()

    print("Success.")





