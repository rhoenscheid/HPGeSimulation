#Python Analysis Script"
import numpy as np
import uproot
import pandas as pd
import matplotlib.pyplot as plt

def plot_histogram(filename):
    """
    Use matplotlib to plot the histogram of deposited energies, given a .root file.
    """

    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]
    
    bin_number = int(np.sqrt(len(energies))/2)
    
    print("Creating histogram with",bin_number,"bins.")

    plt.figure()
    
    plt.hist(energies, bins=bin_number, histtype = 'step')
    plt.xlabel("Energy [MeV]")
    plt.ylabel("Number of Events")
    plt.yscale("log")
    plt.title("Test Run with Co-60 Point Source")

    plt.savefig("hist.png", dpi=300)

    print("Saved histogram.")

def interspec_exp(filename):
    """
    Creates a histogram .csv file, which can be read by InterSpec.
    """

    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]

    #print(len(energies))

    energies = energies*1000 #ocnversion to keV
    #print(min(energies), max(energies))
    #print(energies)

    counts, bin_edges = np.histogram(energies, bins = 4096, range=(0.3336, 2776.831))

    #remove the first bin_edge (=0)
    bin_edges = bin_edges[:-1]

    channels = np.arange(start = 1, stop = 4097, step = 1)


    print("channels ", len(channels))
    print("energies ", len(bin_edges))
    print("counts ", len(counts))
    #print("Total counts: ", np.sum(counts))
    #print("Len energies: ", len(energies))
    table = pd.DataFrame({"Channel" : channels, "Energy (keV)" : bin_edges, "Counts" : counts})

    table.to_csv("Interspec_spectrum.csv", index = False, header = True)

if __name__ == "__main__":

    #plot_histogram("energies_res.csv")

    interspec_exp("energies.csv")
    #plot_histogram("energies_res.csv")

    print("Success.")
