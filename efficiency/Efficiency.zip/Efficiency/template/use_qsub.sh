#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

cd $SCRIPT_DIR

dirlist=("20keV" "30keV" "50keV" "80keV" "100keV" "200keV" "300keV" "500keV" "800keV" "1000keV" "1200keV" "1400keV" "1600keV" "1800keV" "2000keV" "2200keV" "2400keV")

for dir in ${dirlist[@]}; do
  cd $dir
  echo Beginning simulation for $dir...
  singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif g4simple sim_point_source.mac
  singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif python main.py
  rm -r sim_out.root  
  echo Finished simulation for $dir.
  cd ..
done

bash to_merge.sh
cd final_analysis/
singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif python hist_efficiency.py
echo Done.

