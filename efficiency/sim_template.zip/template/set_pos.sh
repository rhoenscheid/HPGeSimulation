#!/bin/bash

dirlist=("20keV" "30keV" "50keV" "80keV" "100keV" "200keV" "300keV" "500keV" "800keV" "1000keV" "1200keV" "1400keV" "1600keV" "1800keV" "2000keV" "2200keV" "2400keV")

filename1="main_sim.gdml"
filename2="final_analysis/hist_efficiency.py"

keymainx="XPOSITION"
keymainy="YPOSITION"
keymainz="ZPOSITION"

keynevents="NEVENTS"

keysimmac="POSITION"

xpos=$1
ypos=$2
zpos=$3
nevents=$4

rep=$xpos" "$ypos" "$zpos

if [[ $keynevents != "" && $nevents != "" ]]; then
  sed -i "s/$keynevents/$nevents/" $filename2
fi

if [[ $xpos != "" && $ypos != "" && $zpos != "" ]]; then
  sed -i "s/$keymainx/$xpos/" $filename1
  sed -i "s/$keymainy/$ypos/" $filename1
  sed -i "s/$keymainz/$zpos/" $filename1
fi

for dir in ${dirlist[@]}; do
  cp $filename1 $dir"/main_sim.gdml"
done


for dir in ${dirlist[@]}; do
  cd $dir
  newfile="sim_point_source.mac"
  if [[ $keysimmac != "" && $rep != "" ]]; then
    sed -i "s/$keysimmac/$rep/" $newfile
    sed -i "s/$keynevents/$nevents/" $newfile
  fi
  cd ..
done

echo All files updated.
