#!bash
mv 20keV/energies.csv merging/energies1.csv
mv 30keV/energies.csv merging/energies2.csv
mv 50keV/energies.csv merging/energies3.csv
mv 80keV/energies.csv merging/energies4.csv
mv 100keV/energies.csv merging/energies5.csv
mv 200keV/energies.csv merging/energies6.csv
mv 300keV/energies.csv merging/energies7.csv
mv 500keV/energies.csv merging/energies8.csv
mv 800keV/energies.csv merging/energies9.csv
mv 1000keV/energies.csv merging/energies10.csv
mv 1200keV/energies.csv merging/energies11.csv
mv 1400keV/energies.csv merging/energies12.csv
mv 1600keV/energies.csv merging/energies13.csv
mv 1800keV/energies.csv merging/energies14.csv
mv 2000keV/energies.csv merging/energies15.csv
mv 2200keV/energies.csv merging/energies16.csv
mv 2400keV/energies.csv merging/energies17.csv

cd merging/
singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif python merge.py

mv energies.csv ../final_analysis/energies.csv

cd ..
echo Done.
