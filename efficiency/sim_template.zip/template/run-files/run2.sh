echo Running 50keV, 80keV and 2200keV simulation.

cd ../50keV
echo Running 50keV simulation
g4simple sim_point_source.mac
echo Analysing 50keV simulation
python main.py

cd ../80keV
echo Running 80keV simulation
g4simple sim_point_source.mac
echo Analysing 80keV simulation
python main.py

cd ../2200keV
echo Running 2200keV simulation
g4simple sim_point_source.mac
echo Analysing 2200keV simulation
python main.py

cd ../run-files
echo Done.

