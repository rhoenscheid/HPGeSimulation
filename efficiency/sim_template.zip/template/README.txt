How to use the efficiency curve generator.

##PREPARATION

Execute "bash set_pos_mac.sh" and type the desired source position in "x y z" format.
Modify main_sim.gdml to the same x,y,z position in the pos_source variable at the start.
Execute "bash set_main_sim.sh" to update the main_sim.gdml file in all simulations.
Execute "bash set_nevents.sh" and enter the number of events processed in each individual simulation


##SIMULATION

#OPTION 1: QSUB
Edit use_qsub.sh: Replace "DIRECTORY" with your present working directory of this simulation.
Type "qsub -q medium use_qsub.sh"
or "qsub -q long use_qsub.sh" depending on how long the job is expected to take.
Using this method, no manual anlalysis is needed.
Collect the output curves after the job has completed in final_analysis/


#OPTION 2: MANUAL
This splits the jobs up into smaller batches to be run simultaneously.
Run each of the run*.sh bash files, which will each run two or three simulations at different energies.
run1.sh - 20keV, 30keV, 2400keV
run2.sh - 50keV, 80keV, 2200keV
run3.sh - 100keV, 200keV, 2000keV
run4.sh - 300keV, 500keV
run5.sh - 800keV, 1000keV
run6.sh - 1200keV, 1400keV
run7.sh - 1600keV, 1800keV 



##ANALYSIS

Once all simulations are finished, run "bash to_merge.sh", which will collect and merge all the data collected for the different energies.
Execute "python hist_efficiency.py" in the final-analysis folder. This will generate the efficiency curves.

