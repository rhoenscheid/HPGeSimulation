#!/bin/bash

xpos=$1
ypos=$2
zpos=$3
nevents=$4

#read -p "X: " xpos
#read -p "Y: " ypos
#read -p "Z: " zpos
#read -p "NEvents: " nevents

filename="P1/main_sim.gdml"
filename2="P1/sim_point_source.mac"
filename3="summary/main_final.py"

rep1="XPOSITION"
rep2="YPOSITION"
rep3="ZPOSITION"


if [[ $rep1 != "" && $xpos != "" ]]; then
  sed -i "s/$rep1/$xpos/" $filename
fi

if [[ $rep2 != "" && $ypos != "" ]]; then
  sed -i "s/$rep2/$ypos/" $filename
fi

if [[ $rep3 != "" && $zpos != "" ]]; then
  sed -i "s/$rep3/$zpos/" $filename
fi

macstring=$xpos" "$ypos" "$zpos

keymac="POSITION"
keynevents="NEVENTS"


if [[ $keymac != "" && $macstring != "" ]]; then
  sed -i "s/$keymac/$macstring/" $filename2
fi

if [[ $keynevents != "" && $nevents != "" ]]; then
  sed -i "s/$keynevents/$nevents/" $filename2
  sed -i "s/$keynevents/$nevents/" $filename3
fi

echo Files updated to: X = $xpos Y = $ypos Z = $zpos Nevents = $nevents






