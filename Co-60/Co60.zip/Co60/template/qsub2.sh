#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

cd $SCRIPT_DIR

files=("P5" "P6" "P7" "P8")

for file in ${files[@]}; do
  cd $file
  singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif g4simple sim_point_source.mac
  singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif python main.py
  rm -r sim_out.root
  mv energies_res.csv ../summary/$file.csv
  cd ..
done
