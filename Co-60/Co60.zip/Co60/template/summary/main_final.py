import hist_class as hs
import merge as mg
import create_hist as ch


def main():

    time = 60654.41
    Nevents = NEVENTS * 8


    mg.main()
    hs.main(Nevents)

    ch.interspec_exp("energies_res.csv")


    factor = hs.get_scaling_factor(time, Nevents)

    print("Factor =", factor)

    ch.scale_hist("Interspec_spectrum.csv", factor)


if __name__ == '__main__':

    main()
