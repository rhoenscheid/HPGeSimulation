import numpy as np
import pandas as pd

def main():
    
    files = ["P1.csv", "P2.csv", "P3.csv", "P4.csv", "P5.csv", "P6.csv", "P7.csv", "P8.csv"]

    sets = [pd.read_csv(filename, header = None) for filename in files]
    
    merged = pd.concat(sets)

    merged.to_csv("energies_res.csv", header = False, index = False)

if __name__ == "__main__":

    main()
