import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def add_resolution_to_peaks(filename, resolution, peaks):
    """
    Adds Gaussian resolution function to specified peaks of the spectrum only.
    Inputs:
    - filename: name of the .csv file, in which the counted energies are saved.
    - resolution: standard deviation of the Gaussian resolution function.
    - peaks: location of the peaks in the spectrum
    """

    print("Adding detector resolution effects...")

    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]

    for i in range(len(peaks)):

        #the values around the peak are affected by the resolution efficiency
        affected_values = energies[energies.between(peaks[i] - 2*resolution, peaks[i] + 2*resolution, inclusive=False)]
        gauss = np.random.normal(0, resolution, len(affected_values))

        affected_values = affected_values + gauss
        energies[energies.between(peaks[i] - 2*resolution, peaks[i] + 2*resolution, inclusive=False)] = affected_values

    energies.to_csv("energies_res.csv", index = False, header = False)

    print("Added detector resolution effects.")


def add_resolution_simple(filename, resolution):
    """
    Adds Gaussian fluctuations to every measurement in the energy spectrum.
    Inputs:
    - filename: name of .csv file, in which the counted energies are saved.
    - resolution: standard deviation of the Gaussian resolution function.
    """

    print("Adding detector resolution effects...")

    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]

    gauss = np.random.normal(0, resolution, len(energies))

    energies = energies + gauss

    energies.to_csv("energies_res.csv", index = False, header = False)

    print("Added detector resolution effects.")

def get_res(energy):
    """
    This is to get the expected detector resolution at a given energy in the spectrum.
    Input:
    - energy (float): energy value at which to evaluate the resolution.
    returns:
    - sigma (float): standard deviation of gaussian error distribution at the energy.
    """
    
    FWHM = 0.0015423 * np.sqrt(energy) #obtained from spec sheet 1332keV value

    sigma = FWHM / 2.355

    return sigma

def add_FWHM_resolution(filename):
    """
    Adds the FWHM resolution effects according to the sqrt(E) relationship of the error
    """
    energies_0 = pd.read_csv(filename, header = None)
    energies = energies_0.iloc[:,0]

    #obtain the standard deviation for each gaussian
    print("Obtaining FWHM at different energies...")
    sigmas = get_res(np.array(energies))
    #write the obtained resolution values in resolution[]
    errors = []
    print("Calculating individual errors...")

    for sigma in sigmas:
        
        gauss = np.random.normal(0, sigma)
        
        errors.append(gauss)

    errors = np.array(errors)
    energies = energies + errors

    print("Errors calculated.")
    print("Saving to energies_res.csv...")

    energies.to_csv("energies_res.csv", index = False, header = False)



if __name__ == "__main__":
    
    add_FWHM_resolution("energies.csv")

    print("Success.")
