#!/bin/bash

echo Beginning Simulation.

singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif g4simple sim_point_source.mac

echo Analysising Simulation.

singularity exec -B /unix /unix/legend/software/ruben/legend-software.sif python main.py

echo Removing sim_out.root...

rm -r sim_out.root

echo Done.
