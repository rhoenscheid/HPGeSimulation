#!bash

cp -r P1 P2
cp -r P1 P3
cp -r P1 P4
cp -r P1 P5
cp -r P1 P6
cp -r P1 P7
cp -r P1 P8

echo Done.
