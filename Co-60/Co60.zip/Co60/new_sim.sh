#!/bin/bash

DIRECTORY="/unix/legend/software/ruben/sim/Co-60"

cd $DIRECTORY

xpos=$1
ypos=$2
zpos=$3
Nevents=$4

datevar=$(date +"%d-%b-%Y-%H-%M")

foldername=$1"-"$2"-"$3"-"$datevar

cp -r template $foldername

cd $foldername

bash set_pos.sh $xpos $ypos $zpos $Nevents

bash qsub.sh

outputname=$xpos"-"$ypos"-"$zpos"-"$Nevents

#cp "summary/hist.png" "../../output/"$outputname"_hist.png"
cp "summary/counts_per_hour.csv" $DIRECTORY"/output/"$outputname"_countsphour.csv"
cp "summary/Interspec_spectrum.csv" $DIRECTORY"/output/"$outputname"_Interspec.csv"
cp "summary/raw_counts.csv" $DIRECTORY"/output/"$outputname"_peak_counts.csv"  


